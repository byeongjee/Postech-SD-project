
public interface TestInterface {
	int return_one();
	int return_the_input(int input);
}
