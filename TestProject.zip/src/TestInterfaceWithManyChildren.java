
public interface TestInterfaceWithManyChildren {
	int return_one();
	int return_the_input(int input);
	int return_the_input_times_ten(int input);
}
