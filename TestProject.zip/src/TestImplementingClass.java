
public class TestImplementingClass implements TestInterface {

	@Override
	public int return_one() {
		return 1;
	}

	@Override
	public int return_the_input(int input) {
		// TODO Auto-generated method stub
		return input;
	}

}
