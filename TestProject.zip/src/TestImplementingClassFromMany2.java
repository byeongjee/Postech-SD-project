
public class TestImplementingClassFromMany2 implements TestInterfaceWithManyChildren {

	@Override
	public int return_one() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int return_the_input(int input) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int return_the_input_times_ten(int input) {
		// TODO Auto-generated method stub
		return 0;
	}

}
