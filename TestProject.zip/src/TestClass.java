
public abstract class TestClass {
	int test_var=10;
	int test_function(int test_input_1,int test_input_2)
	{
		return test_input_1+test_input_2*10;
	}
}