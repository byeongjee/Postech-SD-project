
public class TestChildrenClass extends TestClass {
	int test_Children_var=5;
	int get_test_Children_var() {
		return test_Children_var;
	}
}
